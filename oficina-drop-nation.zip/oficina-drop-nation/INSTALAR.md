# INSTALAR · Oficina Drop Nation

> Instrucciones para Claude. El alumno solo responde lo que le preguntes. Háblale en español de Chile, corto y claro, y **nunca le pidas que escriba comandos**: los corres tú.

## 1 · Dónde estás
Tienes que estar en la app de escritorio de Claude, pestaña **Code**, en una sesión **local** en su computador. Si no (chat normal, navegador o celular), detente y explícale cómo abrir Code con una sesión local.

## 2 · Instalar el paquete
Corre el instalador desde una copia fresca del repositorio:

- **Mac o Linux:**
```bash
cd ~ && rm -rf _dn_tmp && git clone --depth 1 https://github.com/dropnationlatam/OFICINA-DROP-NATION _dn_tmp && bash _dn_tmp/instalar.sh _dn_tmp; rm -rf _dn_tmp
```
- **Windows (PowerShell):**
```powershell
cd ~; Remove-Item -Recurse -Force _dn_tmp -ErrorAction SilentlyContinue; git clone --depth 1 https://github.com/dropnationlatam/OFICINA-DROP-NATION _dn_tmp; powershell -ExecutionPolicy Bypass -File _dn_tmp\instalar.ps1 _dn_tmp; Remove-Item -Recurse -Force _dn_tmp
```

Si `git` no está instalado, pídele permiso e instálalo (Mac: `xcode-select --install`; Windows: `winget install Git.Git`) y vuelve a correrlo. Muéstrale el resultado en simple.

## 3 · Sesión nueva
Dile que **cierre esta sesión y abra una nueva** en Code, sobre la carpeta de su tienda (si todavía no existe, sobre Documentos), y que te escriba: **"deja lista la oficina"**.

## 4 · Dejar la oficina andando
En la sesión nueva usa la skill **cerebro-drop-nation**:
1. Si la tienda no está configurada (`Bases/Contexto de la tienda.md` no existe o no está `completo`), haz la **Parte A**.
2. Después haz la **Parte E · Dejar lista la Oficina Drop Nation**: carpeta `Oficina/`, los 4 conectores, el editor la primera vez, la app **Oficina** (Claude Code, la app con su ícono en Aplicaciones o en el Escritorio, la app de Shopify que configura el alumno y que parta sola al prender el computador) y la prueba `--probar` hasta que diga TODO LISTO.

## Actualizar
Cuando el alumno diga "actualiza la oficina", corre el paso 2 de nuevo y pídele una sesión nueva. Nunca se tocan sus archivos de la tienda: solo se cambian las skills, las plantillas y la oficina visual.
