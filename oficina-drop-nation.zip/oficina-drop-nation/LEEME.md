# Oficina Drop Nation

La oficina de agentes de Claude para tu tienda de dropshipping contra entrega. Cada agente hace una parte del trabajo y le pasa la posta al siguiente:

**Buscador** → *(tú apruebas)* → **Investigador** → **Guionista** → **Editor** → **Campañas** (deja el testeo en borrador) → *(tú publicas)* → **Lectura de campañas** (cada hora y un reporte al día)

Tú solo apruebas productos, publicas los testeos y apagas o escalas lo que digan los reportes. En la oficina tienes además un **visor** con pestañas para ver los anuncios en un reproductor, las fichas con sus fotos, los guiones, el radar y las **métricas** completas (gráficos y la última lectura), y el Gerente te puede mostrar videos, imágenes y gráficos en el chat. Lo demás corre solo en tu computador, en **la oficina**: una app con tu tienda en vivo (ventas, visitas y carritos al minuto) y un chat con el **Gerente**, que es Claude Code trabajando en tu tienda.

## Cómo se instala

1. Abre la app de escritorio de Claude, pestaña **Code**, con una sesión **local** sobre la carpeta de tu tienda (o tu carpeta Documentos si todavía no la tienes).
2. Pégale esto a Claude:

> Instala la Oficina Drop Nation desde https://github.com/dropnationlatam/OFICINA-DROP-NATION siguiendo su archivo INSTALAR.md.

Claude instala todo, configura tu tienda, conecta las herramientas, deja lista la app de la oficina y hace una prueba. Después abres la oficina con la app **Oficina** (en Aplicaciones o el Dock en Mac, en el Escritorio en Windows): se abre en su propia ventana, con su ícono. Para actualizar: cuando salga una versión nueva, el botón **⚙️ Mantenimiento** de la oficina se marca con un punto verde. Ábrelo y toca **Actualizar oficina**: se instala sola y la ventana se recarga. También puedes decirle a Claude: **"actualiza la oficina"**.

En **⚙️ Mantenimiento** también puedes revisar que todo funcione, abrir la carpeta de la tienda, ver el registro de errores, reiniciar el Gerente y cerrar la oficina.

## Qué trae

| Carpeta | Qué es |
|---|---|
| `skills/` | Los agentes: cerebro (el que coordina), buscador, investigador, guionista, editor, campañas y landing (en pausa) |
| `plantillas/` | Los archivos de la oficina (bitácora, bandeja, estado), la app **Oficina** (Mac y Windows) y cómo corre |
| `herramientas/` | La app de la oficina (`oficina.py`), la oficina visual (`Oficina.html`) y el script de datos (`panel.py`) |
| `instalar.sh` / `instalar.ps1` | El instalador (Mac / Windows). Lo corre Claude |

## Qué necesitas

- Computador con la app de escritorio de Claude y Claude Code, prendido y sin suspender mientras la oficina trabaja.
- Plan de Claude que incluya Claude Code (Pro, Max, Team o Enterprise).
- Conectores: **Shopify**, **Meta Ads**, **Apify** y **ElevenLabs**.
- La Fase 1 de Drop Nation lista (Shopify, Dropi y Meta).

Dudas: a la reunión con Paolo.
