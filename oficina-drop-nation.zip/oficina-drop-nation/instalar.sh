#!/bin/bash
# Instala o actualiza la Oficina Drop Nation (Mac y Linux).
# Uso: bash instalar.sh [carpeta del paquete]   (sin carpeta, baja la ultima version de GitHub)
REPO="https://github.com/dropnationlatam/OFICINA-DROP-NATION"
SKILLS="cerebro-drop-nation buscador-drop-nation investigador-drop-nation guionista-drop-nation landing-drop-nation edicion-anuncios-drop-nation campanas-drop-nation"
DEST="$HOME/.claude/skills"
OFI="$HOME/.claude/oficina-drop-nation"
mkdir -p "$DEST" "$OFI"
if [ -n "$1" ]; then SRC="$1"; BORRAR=""; else
  SRC="$HOME/_dn_tmp"; BORRAR="$SRC"; rm -rf "$SRC"
  git clone --depth 1 "$REPO" "$SRC" >/dev/null 2>&1 || { echo "No se pudo bajar la oficina. No se cambio nada."; exit 1; }
fi
[ -d "$SRC/skills" ] || { echo "El paquete no trae la carpeta skills. No se cambio nada."; exit 1; }
for s in $SKILLS; do
  if [ -f "$SRC/skills/$s/SKILL.md" ]; then
    rm -rf "$DEST/$s" && cp -r "$SRC/skills/$s" "$DEST/" && echo "$s: lista"
  else echo "$s: no viene en el paquete, no se cambio"; fi
done
for d in plantillas herramientas; do
  [ -d "$SRC/$d" ] && rm -rf "$OFI/$d" && cp -r "$SRC/$d" "$OFI/" && echo "oficina/$d: lista"
done
[ -f "$SRC/VERSION" ] && cp "$SRC/VERSION" "$OFI/VERSION" && echo "version: $(cat "$OFI/VERSION")"
[ -n "$BORRAR" ] && rm -rf "$BORRAR"
echo "Listo. Cierra esta sesion de Claude y abre una nueva para que aparezcan los cambios."
