---
tipo: oficina-bandeja
---

# Bandeja del alumno

> [!info] INSTRUCCIONES (no borrar)
> Aquí los agentes dejan **lo que te necesitan**: aprobar productos, datos de Dropi, un link, publicar un testeo o una alerta de campañas.
> **Para responder:** marca `[x]` o escribe tu respuesta al final de la misma línea. La oficina la lee en su próxima vuelta (cada hora) y sigue sola.
> **Aprobar productos:** escribe al final `aprobado · <link de Dropi> · <precio proveedor> · <stock>` o `rechazado`.
> **Publicar un testeo** no se hace aquí: escríbele a Claude "publica el testeo de <producto>" o publícalo tú en el Administrador de anuncios.
> Formato de los agentes: `- [ ] AAAA-MM-DD · <agente> · <producto> · <qué necesita>`

---

## Pendiente

