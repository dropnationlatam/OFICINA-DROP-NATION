---
tipo: oficina-bitacora
---

# Bitácora de la oficina

> [!info] INSTRUCCIONES PARA CLAUDE (no borrar)
> Aquí escribe **cada agente** al terminar un trabajo. Una línea por trabajo, **la más nueva arriba**. No se borran líneas.
> Formato: `AAAA-MM-DD HH:MM · <agente> · <producto> · <qué hizo> · <archivo> · → <siguiente agente o "para">`
> Agentes: `oficina` · `buscador` · `investigador` · `guionista` · `editor` · `campañas`.

---

