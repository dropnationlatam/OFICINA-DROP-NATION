---
tipo: oficina-estado
---

# Estado de los agentes

> [!info] INSTRUCCIONES PARA CLAUDE (no borrar)
> Cada agente se pone en `trabajando` al empezar y en `libre` al terminar (o `esperando` si dejó algo en la bandeja). Si un agente está `trabajando` en el mismo producto hace menos de 3 horas, los demás no empiezan ese producto.

---

| Agente | Estado | Producto | Desde |
|---|---|---|---|
| buscador | libre | | |
| investigador | libre | | |
| guionista | libre | | |
| editor | libre | | |
| campañas | libre | | |
| landing | en pausa | | |
