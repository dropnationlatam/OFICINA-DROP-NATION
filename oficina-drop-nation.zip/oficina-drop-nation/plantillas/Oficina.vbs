' Oficina Drop Nation (Windows): arranca la oficina si no esta corriendo y la abre en su propia ventana (Edge en modo app).
Set sh = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
base = sh.ExpandEnvironmentStrings("%USERPROFILE%") & "\.claude\oficina-drop-nation\"
If Not fs.FileExists(base & "tienda.txt") Then
  MsgBox "No encuentro la carpeta de tu tienda. Abre Claude y pidele: deja lista la oficina.", 48, "Oficina Drop Nation"
  WScript.Quit
End If
tienda = Trim(fs.OpenTextFile(base & "tienda.txt", 1, False, -1).ReadLine)
urlf = tienda & "\Oficina\.url"
corriendo = False
On Error Resume Next
Set http = CreateObject("MSXML2.ServerXMLHTTP")
http.setTimeouts 2000, 2000, 2000, 2000
http.Open "GET", "http://localhost:8765/datos.js", False
http.Send
If Err.Number = 0 Then If http.Status = 200 Then corriendo = True
Err.Clear
On Error GoTo 0
If Not corriendo Then
  If fs.FileExists(urlf) Then fs.DeleteFile urlf
  sh.Run "pythonw -I """ & base & "herramientas\oficina.py"" """ & tienda & """ --sin-navegador", 0, False
  For i = 1 To 60
    If fs.FileExists(urlf) Then Exit For
    WScript.Sleep 250
  Next
End If
If Not fs.FileExists(urlf) Then
  MsgBox "La oficina no partio. Abre Claude y pidele: revisa por que no parte la oficina.", 48, "Oficina Drop Nation"
  WScript.Quit
End If
url = Trim(fs.OpenTextFile(urlf, 1, False, 0).ReadLine)
sh.Run "msedge --app=""" & url & """ --window-size=1440,900 --user-data-dir=""" & base & "ventana""", 1, False
