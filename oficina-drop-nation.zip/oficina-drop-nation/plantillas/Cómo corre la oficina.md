# Cómo corre la Oficina Drop Nation

La oficina se abre con la **app Oficina** (Mac: en Aplicaciones o el Dock; Windows: en el Escritorio). Se abre en su propia ventana y, **mientras la oficina esté abierta** (aunque cierres la ventana), hace todo esto sola. Para apagarla del todo, botón **Cerrar oficina** arriba en la ventana:

| Qué | Cuándo |
|---|---|
| Ventas, facturación, visitas y agregados al carrito de Shopify | Cada minuto (con la app de Shopify configurada en `Oficina/oficina.json`) |
| Vuelta de la oficina: revisa la bandeja, lanza al agente que toca y revisa las campañas | Cada hora en punto, de 7 a 23 |
| Reporte del día de campañas | 9:05 |
| Buscador de productos | 12:05 |

**El chat del Gerente** es Claude Code de verdad trabajando en la carpeta de la tienda: se le puede preguntar cómo va todo o pedirle trabajo ("busca 10 productos", "revisa la oficina", "publica el testeo de <producto>"). Publicar o gastar plata siempre pide un sí explícito del jefe en el chat.

**Configuración** en `Oficina/oficina.json`:
- `permisos`: modo de permisos de Claude Code para las tareas (por defecto `auto`).
- `tareas`: `true` para que corran las tareas, `false` para pausarlas.
- `presupuesto_usd_por_tarea`: tope de gasto de cada tarea en Claude Code.
- `horario_tareas`: horas en que corre la vuelta de cada hora (por defecto `7-23`).
- `shopify_tienda`, `shopify_client_id` y `shopify_client_secret`: los pega **el alumno**, nunca en el chat. Salen de una app creada en el Dev Dashboard de Shopify, instalada en su tienda, con permisos `read_orders` y `read_reports`.

**Para revisar que todo funcione:** `python3 -I ~/.claude/oficina-drop-nation/herramientas/oficina.py "<carpeta de la tienda>" --probar` (en Windows, `python`). Tiene que decir TODO LISTO.

Para que corra: computador prendido (la oficina no lo deja dormir mientras está abierta) y Claude Code con la sesión iniciada.
