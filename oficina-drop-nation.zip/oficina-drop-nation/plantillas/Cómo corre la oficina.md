# Cómo corre la Oficina Drop Nation

La oficina se abre con la **app Oficina** (Mac: en Aplicaciones o el Dock; Windows: en el Escritorio). Se abre en su propia ventana y, **mientras la oficina esté abierta** (aunque cierres la ventana), hace todo esto sola. Para apagarla del todo, botón **Cerrar oficina** en **⚙️ Mantenimiento**:

| Qué | Cuándo |
|---|---|
| Ventas, facturación, visitas y agregados al carrito de Shopify | Cada minuto (con la app de Shopify configurada en `Oficina/oficina.json`) |
| Vuelta de la oficina: revisa las campañas (si hay andando) y, si algo cambió, la bandeja y lanza al agente que toca | Cada hora en punto, de 7 a 23 (o cada 2 o 3 horas) |
| Reporte del día de campañas (si hay andando) | 9:05 |
| Buscador de productos | 12:05 |

**El chat del Gerente** es Claude Code de verdad trabajando en la carpeta de la tienda: se le puede preguntar cómo va todo o pedirle trabajo ("busca 10 productos", "revisa la oficina", "publica el testeo de <producto>"). Publicar o gastar plata siempre pide un sí explícito del jefe en el chat.

**Para gastar poco:** Claude solo despierta cuando hay algo que hacer. Si no hay campañas andando ni cambió nada, la vuelta no gasta. Las revisiones y reportes usan un modelo más barato, la revisión de métricas lee un archivo corto en vez de la skill completa y recibe los números de Shopify que la oficina ya leyó, y el Gerente parte una conversación nueva cada día. Si Claude llega al límite del plan, la oficina pausa las tareas una hora, avisa en el chat y en la bandeja, y sigue sola después.

**Configuración** en `Oficina/oficina.json`:
- `permisos`: modo de permisos de Claude Code para las tareas (por defecto `auto`).
- `tareas`: `true` para que corran las tareas, `false` para pausarlas.
- `presupuesto_usd_por_tarea`: tope de gasto de cada tarea en Claude Code.
- `horario_tareas`: horas en que corre la vuelta (por defecto `7-23`).
- `revision_cada_horas`: cada cuántas horas corre la vuelta (`1`, `2` o `3`; con plan Pro conviene `2`).
- `modelo_rutina`: modelo de las revisiones, el reporte y el buscador (por defecto `sonnet`).
- `modelo_trabajo`: modelo de los agentes y el Gerente (vacío = el de la cuenta).
- `shopify_tienda`, `shopify_client_id` y `shopify_client_secret`: los pega **el alumno**, nunca en el chat. Salen de una app creada en el Dev Dashboard de Shopify, instalada en su tienda, con permisos `read_orders` y `read_reports`.

**Para revisar que todo funcione:** `python3 -I ~/.claude/oficina-drop-nation/herramientas/oficina.py "<carpeta de la tienda>" --probar` (en Windows, `python`). Tiene que decir TODO LISTO. Es la misma prueba del botón **Revisar** de ⚙️ Mantenimiento.

Para que corra: computador prendido (la oficina no lo deja dormir mientras está abierta) y Claude Code con la sesión iniciada.

## Mantenimiento

El botón **⚙️ Mantenimiento** de la ventana tiene: versión y **Actualizar oficina** (se marca con un punto verde cuando hay una nueva), **Revisar** (la misma prueba de la instalación), abrir la carpeta de la tienda, ver el registro de errores, **Reiniciar el Gerente** (conversación nueva, sin borrar nada de la tienda) y cerrar la oficina.
