# Instala o actualiza la Oficina Drop Nation (Windows, PowerShell).
# Uso: powershell -ExecutionPolicy Bypass -File instalar.ps1 [carpeta del paquete]
$Repo = "https://github.com/dropnationlatam/OFICINA-DROP-NATION"
$Skills = "cerebro-drop-nation","buscador-drop-nation","investigador-drop-nation","guionista-drop-nation","landing-drop-nation","edicion-anuncios-drop-nation","campanas-drop-nation"
$Dest = Join-Path $HOME ".claude\skills"
$Ofi = Join-Path $HOME ".claude\oficina-drop-nation"
New-Item -ItemType Directory -Force -Path $Dest,$Ofi | Out-Null
$Borrar = $null
if ($args.Count -gt 0) { $Src = $args[0] } else {
  $Src = Join-Path $HOME "_dn_tmp"; $Borrar = $Src
  if (Test-Path $Src) { Remove-Item -Recurse -Force $Src }
  git clone --depth 1 $Repo $Src 2>$null
}
if (-not (Test-Path (Join-Path $Src "skills"))) { Write-Output "No se pudo bajar la oficina. No se cambio nada."; exit 1 }
foreach ($s in $Skills) {
  if (Test-Path (Join-Path $Src "skills\$s\SKILL.md")) {
    $t = Join-Path $Dest $s; if (Test-Path $t) { Remove-Item -Recurse -Force $t }
    Copy-Item -Recurse (Join-Path $Src "skills\$s") $Dest; Write-Output "${s}: lista"
  } else { Write-Output "${s}: no viene en el paquete, no se cambio" }
}
foreach ($d in "plantillas","herramientas") {
  if (Test-Path (Join-Path $Src $d)) {
    $t = Join-Path $Ofi $d; if (Test-Path $t) { Remove-Item -Recurse -Force $t }
    Copy-Item -Recurse (Join-Path $Src $d) $Ofi; Write-Output "oficina/${d}: lista"
  }
}
if (Test-Path (Join-Path $Src "VERSION")) { Copy-Item -Force (Join-Path $Src "VERSION") $Ofi }
if ($Borrar) { Remove-Item -Recurse -Force $Borrar }
Write-Output "Listo. Cierra esta sesion de Claude y abre una nueva para que aparezcan los cambios."
