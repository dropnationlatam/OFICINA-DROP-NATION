# Oficina Drop Nation: deja la oficina al dia en la carpeta de la tienda.
# Copia Oficina.html (el diseno de la oficina) y escribe Oficina/datos.js con lo que
# escribieron los agentes: estado, bitacora, bandeja, tablero y la revision de cada hora.
# El alumno abre Oficina/Oficina.html en el navegador; se actualiza sola cada minuto.
# Uso: python3 -I panel.py "<carpeta de la tienda>"
import sys, os, re, json, shutil, datetime, unicodedata

T = "."
AQUI = os.path.dirname(os.path.abspath(__file__))

def leer(rel):
    try:
        with open(os.path.join(T, rel), encoding="utf-8") as f: return f.read()
    except OSError: return ""

def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn").strip()

def limpio(s):
    s = re.sub(r"\*\(.*?\)\*", "", s)
    return s.replace("**", "").replace("`", "").strip()

def tabla(txt, despues_de=None):
    if despues_de:
        if despues_de not in txt: return []
        txt = txt.split(despues_de, 1)[1]
    filas = []
    for l in txt.splitlines():
        l = l.strip()
        if l.startswith("|") and l.endswith("|"):
            celdas = [limpio(c) for c in l.strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c) for c in celdas if c): continue
            filas.append(celdas)
        elif filas: break
    return filas

def dicts(filas, maximo=50):
    if len(filas) < 2: return []
    cab = filas[0]; out = []
    for f in filas[1:]:
        if all(c in ("", "⏳") for c in f): continue
        out.append({cab[i]: (f[i] if i < len(f) else "") for i in range(len(cab))})
        if len(out) >= maximo: break
    return out

def leer_agentes():
    agentes = {}
    for f in tabla(leer("Oficina/Estado.md"))[1:]:
        f = f + [""] * 4
        agentes[norm(f[0]).replace("ñ", "n")] = {"estado": f[1], "producto": f[2], "desde": f[3]}
    return agentes

# Bitacora: AAAA-MM-DD HH:MM · agente · producto · que hizo · archivo · → siguiente
def leer_bitacora():
    bitacora = []
    for l in leer("Oficina/Bitácora.md").splitlines():
        l = l.strip().lstrip("-").strip()
        m = re.match(r"(\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2})\s*·\s*(.*)", l)
        if not m: continue
        partes = [p.strip() for p in m.group(2).split("·")]
        sig = ""
        if partes and partes[-1].startswith("→"):
            sig = partes.pop().lstrip("→").strip()
        partes += [""] * 4
        bitacora.append({"t": m.group(1), "agente": partes[0], "producto": partes[1],
                         "que": partes[2], "archivo": " · ".join(p for p in partes[3:] if p), "sig": sig})
    bitacora.sort(key=lambda b: b["t"], reverse=True)
    bitacora = bitacora[:80]
    return bitacora

# Bandeja: - [ ] AAAA-MM-DD · agente · producto · que necesita
def leer_bandeja():
    bandeja = []
    for l in leer("Oficina/Bandeja.md").splitlines():
        l = l.strip()
        if not l.startswith("- [ ]"): continue
        partes = [p.strip() for p in l[5:].split("·")]
        if len(partes) >= 4:
            bandeja.append({"fecha": partes[0], "agente": partes[1], "producto": partes[2], "texto": " · ".join(partes[3:]), "linea": l})
        else:
            bandeja.append({"fecha": "", "agente": "oficina", "producto": "", "texto": l[5:].strip(), "linea": l})
    return bandeja

def nombre_tienda():
    """El nombre de la tienda sale de Bases/Contexto de la tienda.md; si no esta, del nombre de la carpeta."""
    for f in tabla(leer("Bases/Contexto de la tienda.md"), "## Shopify"):
        if len(f) > 1 and norm(f[0]) == "nombre de la tienda" and f[1] not in ("", "⏳"):
            return f[1]
    return os.path.basename(os.path.abspath(T)).replace(" - Claude", "")

def construir(tienda):
    """Arma los datos de la oficina para la carpeta de la tienda."""
    global T
    T = tienda
    return {
        "generado": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "tienda": nombre_tienda(),
        "agentes": leer_agentes(),
        "bitacora": leer_bitacora(),
        "bandeja": leer_bandeja(),
        "tablero": dicts(tabla(leer("Bases/Tablero de productos.md"))),
        "horas": dicts(tabla(leer("Bases/Reportes de la tienda.md"), "## Cada hora"), 6),
    }

def escribir(tienda):
    datos = construir(tienda)
    os.makedirs(os.path.join(tienda, "Oficina"), exist_ok=True)
    with open(os.path.join(tienda, "Oficina", "datos.js"), "w", encoding="utf-8") as f:
        f.write("window.OFICINA = " + json.dumps(datos, ensure_ascii=False) + ";\n")
    destino = os.path.join(tienda, "Oficina", "Oficina.html")
    origen = os.path.join(AQUI, "Oficina.html")
    if os.path.exists(origen):
        shutil.copyfile(origen, destino)
    return destino

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Uso: python3 -I panel.py "<carpeta de la tienda>"'); sys.exit(1)
    print("Oficina al día:", escribir(sys.argv[1]))
