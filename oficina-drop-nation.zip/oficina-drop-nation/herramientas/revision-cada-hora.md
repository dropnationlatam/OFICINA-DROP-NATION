# Revisión de cada hora · Oficina Drop Nation

> Versión corta de la **Parte 4 de campanas-drop-nation**, para que la oficina la corra cada hora sin cargar la skill completa (gasta mucho menos). Si cambias la Parte 4 de la skill, cambia también este archivo.

**Modo automático:** no preguntes nada, solo lees y anotas. **Nunca** publiques, apagues, pauses ni cambies nada en Meta ni en Shopify: lo que haya que apagar va a la bandeja y lo aprueba el alumno con su botón. No inventes datos: si falta uno, "sin dato".

**Qué campañas leer:** las de `Productos/<producto>/Campañas.md` con **Estado: publicada**, y en ellas los Ads con estado `activo`. La campaña parte a las 4:00 del día en que se publicó (o del siguiente): el **día 1** cuenta desde ahí. La cuenta es la que dice "para vender" en `Bases/Contexto de la tienda.md`.

## Qué hacer

Se corre **cada hora** con la tarea programada de la oficina (o cuando el alumno pide "revisa la última hora"). Es corta: **no reemplaza al reporte del día** y casi nunca decide. Solo lee.

1. **Trae lo de hoy.** Si el pedido trae los números de Shopify de hoy (los lee la oficina cada minuto), úsalos tal cual y **no** consultes Shopify. Si no, tráelos con su conector. Con el conector de Meta, por cada campaña andando y cada Ad activo: gasto, compras, CPC, carritos, información de pago y estado de entrega (si Meta lo rechazó o tiene errores). De Shopify, los pedidos de hoy y la facturación de hoy (la suma de esos pedidos), y con su conector de analítica (ShopifyQL: `FROM sessions SHOW sessions, sessions_with_cart_additions, added_to_cart_rate DURING today`) las **visitas** de hoy, los **agregados al carrito** y el **% de agregados al carrito**.
2. **Compara con la revisión anterior** (la última línea de "Cada hora" en `Bases/Reportes de la tienda.md`): qué se gastó en la hora y qué ventas nuevas entraron.
3. **Alertas, solo estas:**

| Lo que se ve | Alerta |
|---|---|
| Un Ad o campaña en **día 1** cumple una regla de corte de la tabla (CPC a CLP 3.000, carrito a CLP 5.000, venta a CLP 8.000) | "Apagar <Ad>: <regla>". No lo apagas tú: el alumno lo aprueba con el botón **Apagar** de su bandeja |
| Un anuncio rechazado por Meta o con error de entrega | "Revisar <Ad>: <motivo de Meta>" |
| Una campaña activa sin gasto en las últimas 3 horas (entre 8:00 y 23:00) | "<Campaña> no está gastando" |
| Pedidos de Shopify de hoy y compras de Meta de hoy no calzan por 3 o más | "El conteo no calza hoy" |
| Ventas nuevas en la hora | No es alerta: solo se anota ("+2 ventas · <producto>") |

   Todo lo demás (mantener, ganador, escalar, bajar) **espera al reporte del día**: con una hora de datos no se decide.
4. **Escribe:**
   - Una línea arriba en la sección **Cada hora** de `Bases/Reportes de la tienda.md`: hora · facturación de hoy · pedidos de Shopify de hoy · visitas de hoy · agregados al carrito de hoy · % agregados al carrito · compras de Meta de hoy · gasto de hoy · CPA de la tienda de hoy · ventas nuevas en la hora · alertas. Deja solo las últimas 48 líneas. Usa siempre esos encabezados: la oficina visual los lee para su recepción.
   - En el `Métricas.md` de cada producto con campañas andando, **reemplaza** la sección **Hoy (cada hora)** con sus números de hoy por campaña. Es la única sección que se pisa: los reportes de abajo nunca se tocan.
   - Cada alerta va también a la **bandeja**, una línea por alerta: `- [ ] AAAA-MM-DD · campañas · <producto> · <alerta>` (así la de apagar sale con sus botones), y a la bitácora. Si la sesión puede mandar una notificación al celular, avisa solo cuando hay una alerta nueva (no la misma de la hora anterior).

## Si falta un archivo

- `Bases/Reportes de la tienda.md`: créalo con este encabezado y deja las secciones `## Resumen` y `## Reportes` vacías para el reporte del día.

````markdown
---
tipo: reportes-tienda
ultimo_reporte: 
---

# Reportes de la tienda

## Cada hora
> Una línea por revisión de cada hora (Parte 4), la más nueva arriba. Solo las últimas 48.

| Hora | Facturación hoy | Pedidos Shopify hoy | Visitas hoy | Agregados al carrito hoy | % agregados al carrito | Compras Meta hoy | Gasto hoy | CPA tienda hoy | Ventas nuevas | Alertas |
|---|---|---|---|---|---|---|---|---|---|---|
| ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
````

- La sección de cada `Métricas.md` que reemplazas (si no existe, agrégala arriba de `## Reportes`):

````markdown
## Hoy (cada hora)
> La reemplaza la revisión de cada hora (Parte 4). Se pisa; lo de abajo no.

*Actualizado: ⏳ HH:MM*
| Campaña | Gasto hoy | Compras hoy | CPA hoy | CPC hoy | Carritos | Info de pago | Alerta |
|---|---|---|---|---|---|---|---|
| ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
````

Al terminar, si hubo una alerta, anota una línea en `Oficina/Bitácora.md`: `AAAA-MM-DD HH:MM · campañas · <producto> · revisión de cada hora: <alerta> · Bases/Reportes de la tienda.md · → para`. Si no hubo alertas, no escribas en la bitácora.
