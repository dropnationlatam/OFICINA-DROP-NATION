# Oficina Drop Nation: la app local de la oficina.
# - Sirve la oficina visual en http://localhost:8765 con los datos de la carpeta de la tienda.
# - El chat del Gerente es Claude Code de verdad (claude -p) trabajando en la carpeta de la tienda.
# - Corre las tareas de la oficina a su hora: cada hora (despachador), 9:00 (reporte) y 12:00 (buscador).
# Uso: python3 -I oficina.py "<carpeta de la tienda>"   (en Windows: python -I oficina.py ...)
import sys, os, json, time, uuid, shutil, secrets, threading, subprocess, datetime, webbrowser, importlib.util, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("panel", os.path.join(AQUI, "panel.py"))
panel = importlib.util.module_from_spec(spec); spec.loader.exec_module(panel)

if len(sys.argv) < 2:
    print('Uso: python3 -I oficina.py "<carpeta de la tienda>"'); sys.exit(1)
TIENDA = os.path.abspath(sys.argv[1])
OFI = os.path.join(TIENDA, "Oficina")
os.makedirs(OFI, exist_ok=True)
PUERTO = 8765
_CLAVE_RUTA = os.path.join(OFI, ".clave")
try: CLAVE = open(_CLAVE_RUTA).read().strip()
except OSError: CLAVE = ""
if len(CLAVE) < 16:
    CLAVE = secrets.token_urlsafe(16)
    try: open(_CLAVE_RUTA, "w").write(CLAVE)
    except OSError: pass
CONF_RUTA = os.path.join(OFI, "oficina.json")
CONF = {"permisos": "auto", "tareas": True, "presupuesto_usd_por_tarea": 5,
        "shopify_tienda": "", "shopify_client_id": "", "shopify_client_secret": "", "shopify_token": "", "shopify_api": "2026-10",
        "horario_tareas": "7-23", "revision_cada_horas": 1,
        "modelo_rutina": "sonnet", "modelo_trabajo": ""}
try:
    CONF.update(json.load(open(CONF_RUTA, encoding="utf-8")))
except (OSError, ValueError):
    pass
json.dump(CONF, open(CONF_RUTA, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

GERENTE = ("Eres el Gerente de la Oficina Drop Nation de esta tienda y hablas por el chat de la oficina. "
           "Al dueño le dices 'jefe'. Español de Chile, mensajes cortos, sin jerga. Trabajas en la carpeta de la tienda (el directorio actual). "
           "Para saber qué pasa lee Oficina/Estado.md, Oficina/Bitácora.md, Oficina/Bandeja.md, Bases/Tablero de productos.md y Bases/Reportes de la tienda.md. "
           "Cuando el jefe te pida algo, hazlo con las skills de Drop Nation (cerebro-drop-nation y la del agente que corresponda) y anota en la bitácora como dicen las skills. "
           "Si aprueba productos o responde algo de la bandeja, anótalo donde corresponde (radar, bandeja). "
           "Nunca publiques campañas, subas presupuestos, publiques en Shopify ni gastes plata sin un sí explícito del jefe en este chat que nombre qué se publica. "
           "No hagas preguntas de opciones: pregunta en texto, en una sola línea. "
           "Mientras trabajas, cuéntale al jefe en una línea corta qué vas haciendo antes de cada paso importante "
           "(por ejemplo: 'Editando el Ad 2: subtítulos', 'Exportando el Ad 2', 'Subiendo los videos a Meta'). "
           "Si el jefe te escribe mientras trabajas, respóndele corto y sigue con lo que estabas haciendo. "
           "Los mensajes que empiezan con [Bandeja] son botones que apretó el jefe en su bandeja: valen como su respuesta y su aprobación para eso exacto; hazlo al tiro sin volver a preguntar. "
           "Para mostrarle algo al jefe en la oficina (un video, una imagen, un gráfico o un archivo .md), escribe en una línea sola `[ver: <ruta dentro de la carpeta de la tienda>]`, por ejemplo `[ver: Productos/Corrector de postura/Anuncios/Videos ads/Ad 1.mp4]`; la oficina lo muestra en el chat. "
           "Si necesitas mostrar un gráfico o una imagen que no existe, créala con código en Oficina/Visuales/ (png) y muéstrala igual. "
           "La oficina también tiene un visor con pestañas (Anuncios, Productos, Guiones, Radar, Métricas, Visuales): si el jefe quiere ver todos los anuncios o las métricas, dile que están ahí. "
           "Todo lo que necesite aprobación del jefe (productos, publicar un testeo, apagar un anuncio, un dato que falta) déjalo en Oficina/Bandeja.md con el formato de las skills, en vez de preguntarlo en el chat.")

def en_horario(n):
    """La vuelta de cada hora corre solo en este horario (oficina.json, horario_tareas, por defecto 7 a 23) para no gastar de noche."""
    try:
        ini, fin = [int(x) for x in str(CONF.get("horario_tareas", "7-23")).split("-")]
    except ValueError:
        return True
    return ini <= n.hour <= fin

def toca_vuelta(n):
    """La vuelta corre a la hora en punto, dentro del horario, cada 'revision_cada_horas' horas (1, 2 o 3)."""
    if n.minute != 0 or not en_horario(n): return False
    try: cada = max(1, int(CONF.get("revision_cada_horas", 1)))
    except (TypeError, ValueError): cada = 1
    try: ini = int(str(CONF.get("horario_tareas", "7-23")).split("-")[0])
    except ValueError: ini = 0
    return (n.hour - ini) % cada == 0

HERR = os.path.dirname(os.path.abspath(__file__))
TAREAS = [
    {"id": "hora", "nombre": "Oficina · vuelta", "cuando": toca_vuelta, "fn": "vuelta"},
    {"id": "reporte", "nombre": "Reporte del día", "cuando": lambda n: n.hour == 9 and n.minute == 5, "modelo": "rutina",
     "si": "campanas", "prompt": "Modo automático: usa la skill campanas-drop-nation y haz el reporte de la tienda (Parte 3; si hay un solo testeo, la Parte 2)."},
    {"id": "buscador", "nombre": "Buscador del día", "cuando": lambda n: n.hour == 12 and n.minute == 5, "modelo": "rutina",
     "prompt": "Modo automático: usa la skill buscador-drop-nation y busca 10 productos. Deja los nuevos en la bandeja."},
]
PROMPT_METRICAS = ("Modo automático. Lee el archivo \"" + os.path.join(HERR, "revision-cada-hora.md") + "\" y haz la revisión de cada hora que explica, "
                   "sin cargar otras skills. Solo lees y anotas: no publiques, no apagues ni cambies nada en Meta ni en Shopify.")
PROMPT_DESPACHO = ("Modo automático: usa la skill cerebro-drop-nation, Parte D. La revisión de métricas de esta hora ya la hizo la oficina: "
                   "salta el paso 1 y parte por la bandeja. Lanza lo pendiente. No publiques nada.")

def claude_bin():
    for n in ("claude", "claude.cmd", "claude.exe"):
        p = shutil.which(n)
        if p: return p
    for p in (os.path.expanduser("~/.local/bin/claude"), os.path.expanduser("~/.claude/local/claude")):
        if os.path.exists(p): return p
    return None

def registro(txt):
    with open(os.path.join(OFI, "Tareas.log"), "a", encoding="utf-8") as f:
        f.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M") + " · " + txt + "\n")

# En Windows, que ningun proceso abra una ventana de comandos
# (consola oculta que heredan todos los procesos hijos: ni Claude ni sus comandos abren ventanas)
def _sin_ventana():
    if os.name != "nt": return {}
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0  # SW_HIDE
    return {"creationflags": subprocess.CREATE_NEW_CONSOLE, "startupinfo": si}
SIN_VENTANA = _sin_ventana()

# ---------- feed: lo que va pasando, para el chat y la oficina
FEED = []
candado_feed = threading.Lock()
def avisar(quien, tipo, texto, agente="oficina"):
    """quien: gerente | tarea · tipo: texto (chat) | paso (logs) | fin | error · agente: quien hace el paso"""
    texto = str(texto or "").strip()
    if not texto: return
    with candado_feed:
        ult = next((x for x in reversed(FEED) if x["quien"] == quien), None)
        if tipo == "paso" and ult and ult["tipo"] == "paso" and ult["texto"] == texto[:1200]:
            return  # no repetir el mismo paso seguido
        n = (FEED[-1]["n"] + 1) if FEED else 1
        FEED.append({"n": n, "hora": datetime.datetime.now().strftime("%H:%M"), "quien": quien, "tipo": tipo, "texto": texto[:1200], "agente": agente})
        if len(FEED) > 600: del FEED[:200]

SKILL_AGENTE = {"buscador": "buscador", "investigador": "investigador", "guionista": "guionista", "edicion": "editor",
                "campanas": "campanas", "landing": "landing", "cerebro": "oficina"}

def base(ruta):
    return os.path.basename(str(ruta or "").rstrip("/\\")) or str(ruta or "")

def paso_legible(nombre, entrada):
    """Convierte una herramienta que usa Claude en una frase corta para el jefe."""
    e = entrada or {}
    if nombre == "Bash": return e.get("description") or "Corriendo un comando"
    if nombre == "Skill": return ""
    if nombre in ("Read", "NotebookRead", "Glob", "Grep", "LS", "ToolSearch"): return ""
    if nombre in ("Write", "Edit", "MultiEdit", "NotebookEdit"):
        arch = base(e.get("file_path") or e.get("notebook_path"))
        return "Guardando " + arch if arch.lower().endswith((".md", ".mp4", ".jpg", ".png", ".json")) else ""
    if nombre == "WebSearch": return "Buscando en internet: " + str(e.get("query") or "")
    if nombre == "WebFetch": return "Leyendo una página web"
    if nombre in ("TodoWrite", "TaskCreate", "TaskUpdate"): return ""
    if nombre in ("Task", "Agent"): return "Mandando a un ayudante: " + str(e.get("description") or "")
    if nombre.startswith("mcp__"):
        partes = nombre.split("__")
        srv, herr = (partes[1] if len(partes) > 1 else ""), (partes[-1] if len(partes) > 2 else "")
        nombres = {"META": "Meta Ads", "Shopify": "Shopify", "Apify": "Apify", "ElevenLabs": "ElevenLabs"}
        srv = next((v for k, v in nombres.items() if k.lower() in srv.lower()), srv)
        return f"{srv}: {herr.replace('_', ' ').replace('-', ' ')}".strip(": ")
    return nombre

def leer_eventos(proc, quien, al_terminar=None, al_iniciar=None):
    """Lee el streaming de Claude Code (stream-json) y lo va pasando al feed:
    lo que dice Claude va al chat (si es el Gerente) y los pasos van a los logs, con el agente que los hace."""
    final = {"ok": False, "texto": ""}
    agente = {"id": "oficina"}
    for linea in proc.stdout:
        linea = linea.strip()
        if not linea: continue
        try: ev = json.loads(linea)
        except ValueError: continue
        tipo = ev.get("type")
        if tipo == "system" and ev.get("subtype") == "init" and al_iniciar:
            al_iniciar(ev.get("session_id"))
        elif tipo == "assistant":
            for b in (ev.get("message") or {}).get("content") or []:
                if b.get("type") == "text" and b.get("text", "").strip():
                    if quien == "gerente":
                        avisar(quien, "texto", b["text"], agente["id"])
                    else:  # en las tareas, lo que narra Claude va resumido a los logs
                        avisar(quien, "paso", b["text"].strip().split("\n")[0][:160], agente["id"])
                elif b.get("type") == "tool_use":
                    if b.get("name") == "Skill":
                        sk = str((b.get("input") or {}).get("skill") or "").lower()
                        agente["id"] = next((v for k, v in SKILL_AGENTE.items() if k in sk), agente["id"])
                    avisar(quien, "paso", paso_legible(b.get("name", ""), b.get("input")), agente["id"])
        elif tipo == "result":
            final = {"ok": not ev.get("is_error"), "texto": ev.get("result") or "", "sesion": ev.get("session_id")}
            agente["id"] = "oficina"
            if al_terminar: al_terminar(final)
    return final

def modelo_de(tipo):
    """'rutina' = revisiones y reportes (más barato) · 'trabajo' = agentes y Gerente ('' = el modelo por defecto de la cuenta)."""
    return str(CONF.get("modelo_" + tipo, "") or "").strip() if tipo else ""

def comando_claude(extra=None, sesion=None, entrada_stream=False, modelo=""):
    cmd = [claude_bin(), "-p", "--output-format", "stream-json", "--verbose",
           "--permission-mode", CONF["permisos"], "--max-budget-usd", str(CONF.get("presupuesto_usd_por_tarea", 5))]
    if modelo: cmd += ["--model", modelo]
    if entrada_stream: cmd += ["--input-format", "stream-json"]
    if sesion: cmd += ["--resume", sesion]
    if extra: cmd += ["--append-system-prompt", extra]
    return cmd

def correr_claude(prompt, quien="tarea", extra=None, timeout=7200, modelo=""):
    """Corre una tarea de Claude Code de punta a punta, contando cada paso en el feed."""
    if not claude_bin():
        return {"ok": False, "texto": "No encuentro Claude Code en este computador."}
    try:
        proc = subprocess.Popen(comando_claude(extra, modelo=modelo) + [prompt], cwd=TIENDA, stdin=subprocess.DEVNULL,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", **SIN_VENTANA)
    except OSError as e:
        return {"ok": False, "texto": "No pude abrir Claude Code: " + str(e)}
    reloj_corte = threading.Timer(timeout, proc.kill); reloj_corte.start()
    final = leer_eventos(proc, quien)
    proc.wait(); reloj_corte.cancel()
    if not final.get("texto") and not final.get("ok"):
        final["texto"] = (proc.stderr.read() or "Claude Code no respondió.").strip()[-400:]
    if not final.get("ok"): revisar_limite(final.get("texto", ""))
    return final

# ---------- ventas, visitas y carritos de Shopify al minuto
# Necesita una app de la tienda creada en el Dev Dashboard de Shopify (permisos read_orders y read_reports),
# instalada en la tienda. El alumno pega en Oficina/oficina.json su client_id y client_secret (nunca en el chat).
# Con eso la oficina pide sola un token cada 24 horas. Tambien acepta un token fijo de una app antigua (shopify_token).
import urllib.request, urllib.error
VIVO = {}
TOKEN = {"valor": "", "vence": 0}

def dominio():
    d = (CONF.get("shopify_tienda") or "").strip().replace("https://", "").replace("http://", "").strip("/")
    if d and not d.endswith(".myshopify.com"): d += ".myshopify.com"
    return d

def token_shopify():
    if (CONF.get("shopify_token") or "").strip():
        return CONF["shopify_token"].strip()
    cid, sec = (CONF.get("shopify_client_id") or "").strip(), (CONF.get("shopify_client_secret") or "").strip()
    if not (dominio() and cid and sec): return ""
    if TOKEN["valor"] and time.time() < TOKEN["vence"]: return TOKEN["valor"]
    cuerpo = urllib.parse.urlencode({"grant_type": "client_credentials", "client_id": cid, "client_secret": sec}).encode()
    req = urllib.request.Request(f"https://{dominio()}/admin/oauth/access_token", data=cuerpo,
                                 headers={"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json", "User-Agent": "OficinaDropNation"})
    with urllib.request.urlopen(req, timeout=20) as r:
        j = json.load(r)
    TOKEN["valor"] = j.get("access_token", "")
    TOKEN["vence"] = time.time() + int(j.get("expires_in") or 3600) - 300
    return TOKEN["valor"]

def gql(query, variables):
    tk = token_shopify()
    if not tk: return None
    cuerpo = json.dumps({"query": query, "variables": variables}).encode()
    req = urllib.request.Request(f"https://{dominio()}/admin/api/{CONF.get('shopify_api', '2026-10')}/graphql.json", data=cuerpo,
                                 headers={"X-Shopify-Access-Token": tk, "Content-Type": "application/json", "User-Agent": "OficinaDropNation"})
    with urllib.request.urlopen(req, timeout=20) as r:
        j = json.load(r)
    if j.get("errors"): raise ValueError(str(j["errors"])[:120])
    return j.get("data") or {}

PEDIDOS = """query($q:String!){orders(first:250, query:$q, sortKey:CREATED_AT, reverse:true){nodes{
 name createdAt cancelledAt totalPriceSet{shopMoney{amount}} lineItems(first:1){nodes{title}}}}}"""

def leer_ventas():
    hoy = datetime.datetime.now().astimezone().replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    d = gql(PEDIDOS, {"q": f"created_at:>='{hoy}'"})
    if d is None: return
    pedidos = [o for o in ((d.get("orders") or {}).get("nodes") or []) if not o.get("cancelledAt")]
    def monto(o):
        try: return float(o["totalPriceSet"]["shopMoney"]["amount"])
        except (KeyError, TypeError, ValueError): return 0.0
    def hora(o):
        try: return datetime.datetime.fromisoformat(o["createdAt"].replace("Z", "+00:00")).astimezone().strftime("%H:%M")
        except (KeyError, ValueError): return ""
    VIVO.pop("error", None)
    VIVO.update({
        "actualizado": datetime.datetime.now().strftime("%H:%M"),
        "pedidos": len(pedidos),
        "facturacion": round(sum(monto(o) for o in pedidos)),
        "ultimas": [{"hora": hora(o),
                     "producto": (((o.get("lineItems") or {}).get("nodes") or [{}])[0].get("title") or o.get("name") or ""),
                     "monto": round(monto(o))} for o in pedidos[:5]],
    })

SESIONES = "query($q:String!){shopifyqlQuery(query:$q){parseErrors tableData{columns{name} rows}}}"

def leer_trafico():
    """Visitas, sesiones con agregado al carrito y % de agregados al carrito de hoy (ShopifyQL)."""
    res = None
    for rango in ("DURING today", "SINCE today"):
        d = gql(SESIONES, {"q": "FROM sessions SHOW sessions, sessions_with_cart_additions, added_to_cart_rate " + rango})
        if d is None: return
        res = d.get("shopifyqlQuery") or {}
        if not res.get("parseErrors"): break
    tabla = (res or {}).get("tableData") or {}
    filas = tabla.get("rows") or []
    if not filas: return
    fila = filas[0]
    if isinstance(fila, list):
        fila = {c.get("name"): v for c, v in zip(tabla.get("columns") or [], fila)}
    def n(v):
        try: return float(v)
        except (TypeError, ValueError): return None
    vis, car, pct = n(fila.get("sessions")), n(fila.get("sessions_with_cart_additions")), n(fila.get("added_to_cart_rate"))
    if pct is None and vis: pct = (car or 0) / vis
    if vis is not None: VIVO["visitas"] = int(vis)
    if car is not None: VIVO["carritos"] = int(car)
    if pct is not None: VIVO["pct_carrito"] = round(pct * 100, 1)

def ventas_al_minuto():
    while True:
        try: leer_ventas()
        except Exception as e: VIVO.update({"error": "Shopify no respondió: " + str(getattr(e, "code", "") or e)[:80]})
        try: leer_trafico()
        except Exception: pass
        time.sleep(60)

# ---------- tareas programadas
ESTADO = {"corriendo": None, "ultima": {}, "proxima": ""}
candado_tareas = threading.Lock()

# ---------- ahorro: Claude solo despierta cuando hay algo que hacer
import re, glob
LIMITE = {"hasta": 0, "aviso": ""}
PAT_LIMITE = re.compile(r"usage limit|limit reached|hit your limit|weekly limit|session limit|out of (extra )?usage|credit balance is too low", re.I)

def revisar_limite(texto):
    """Si Claude llegó al límite del plan, la oficina pausa las tareas una hora y le avisa al jefe una vez al día."""
    if not PAT_LIMITE.search(texto or ""): return False
    LIMITE["hasta"] = time.time() + 3600
    hoy = datetime.date.today().isoformat()
    registro("Claude llegó al límite de uso: tareas en pausa una hora")
    if LIMITE["aviso"] != hoy:
        LIMITE["aviso"] = hoy
        avisar("gerente", "texto", "Jefe, Claude llegó al límite de uso de tu plan. Pauso las tareas automáticas y vuelvo a intentar en una hora. Te lo dejé en la bandeja.")
        try:
            with open(BAN_RUTA, "a", encoding="utf-8") as f:
                f.write(f"\n- [ ] {hoy} · oficina · Claude · llegó al límite de uso del plan: las tareas se pausan y se reintentan cada hora. Si pasa seguido, pídele a Claude que deje la revisión cada 2 o 3 horas, o mejora tu plan\n")
        except OSError: pass
    return True

def en_pausa_por_limite():
    return time.time() < LIMITE["hasta"]

def campanas_activas():
    """Hay campañas andando si algún Campañas.md dice 'publicada' y no está todo apagado."""
    for ruta in glob.glob(os.path.join(TIENDA, "Productos", "*", "Campañas.md")):
        try: txt = open(ruta, encoding="utf-8", errors="replace").read()
        except OSError: continue
        if re.search(r"Estado:\**\s*publicada", txt, re.I) and re.search(r"\|\s*activo\s*\|", txt, re.I):
            return True
    return False

VUELTA_RUTA = os.path.join(OFI, ".vuelta.json")
NO_MIRAR = ("Métricas.md", "Reportes de la tienda.md")
def firma_carpeta():
    """Última modificación de lo que mueve la cadena (radar, productos, bandeja, estado), sin contar lo que escribe la revisión de métricas."""
    m = 0.0
    rutas = [os.path.join(OFI, "Bandeja.md"), os.path.join(OFI, "Estado.md")]
    for raiz in ("Radar", "Productos"):
        for d, _, archivos in os.walk(os.path.join(TIENDA, raiz)):
            rutas += [os.path.join(d, a) for a in archivos if a not in NO_MIRAR]
    for r in rutas:
        try: m = max(m, os.path.getmtime(r))
        except OSError: pass
    return round(m, 1)

def leer_vuelta():
    try: return json.load(open(VUELTA_RUTA, encoding="utf-8"))
    except (OSError, ValueError): return {}

def quedo_pendiente():
    """Mira la última línea de vuelta de la bitácora: si dijo 'nada pendiente', no queda nada por lanzar."""
    try:
        lineas = [l for l in open(os.path.join(OFI, "Bitácora.md"), encoding="utf-8", errors="replace").read().splitlines() if "· vuelta ·" in l]
        return not (lineas and "nada pendiente" in lineas[-1].lower())
    except OSError:
        return True

def una_tarea(nombre, prompt, modelo):
    ESTADO["corriendo"] = nombre; registro(nombre + " · parte"); avisar("tarea", "paso", "Parte: " + nombre)
    r = correr_claude(prompt, quien="tarea", modelo=modelo)
    registro(nombre + (" · terminó" if r["ok"] else " · falló: " + r["texto"][:200]))
    avisar("tarea", "fin" if r["ok"] else "error", nombre + (" · terminó" if r["ok"] else " · falló: " + r["texto"][:200]))
    return r

def prompt_metricas():
    """Le pasa a Claude los números de Shopify que la oficina ya leyó: así no gasta consultándolos de nuevo."""
    datos = {k: VIVO[k] for k in ("pedidos", "facturacion", "visitas", "carritos", "pct_carrito") if k in VIVO}
    if not datos: return PROMPT_METRICAS
    return PROMPT_METRICAS + " Números de Shopify de hoy, leídos por la oficina hace menos de un minuto (úsalos y no consultes Shopify): " + json.dumps(datos, ensure_ascii=False)

def vuelta():
    """Cada vuelta: métricas solo si hay campañas andando (modelo barato); despachador solo si algo cambió o quedó pendiente."""
    hizo = False
    if campanas_activas():
        una_tarea("Revisión de métricas", prompt_metricas(), modelo_de("rutina")); hizo = True
        if en_pausa_por_limite(): return
    v = leer_vuelta(); firma = firma_carpeta()
    seguridad = time.time() - v.get("cuando", 0) > 6 * 3600
    if firma != v.get("firma") or v.get("pendiente", True) or seguridad:
        r = una_tarea("Despachador", PROMPT_DESPACHO, modelo_de("trabajo")); hizo = True
        if r["ok"]:
            json.dump({"firma": firma_carpeta(), "pendiente": quedo_pendiente(), "cuando": time.time()}, open(VUELTA_RUTA, "w"))
    if not hizo:
        registro("Oficina · vuelta · sin cambios ni campañas andando: no desperté a Claude")
        avisar("tarea", "paso", "Vuelta: sin cambios, Claude descansa")

def correr_tarea(t):
    if en_pausa_por_limite():
        registro(t["nombre"] + " · saltada: Claude está en su límite de uso"); return
    if t.get("si") == "campanas" and not campanas_activas():
        registro(t["nombre"] + " · saltada: no hay campañas andando"); return
    if not candado_tareas.acquire(blocking=False):
        registro(t["nombre"] + " · saltada: otra tarea sigue corriendo"); return
    try:
        if t.get("fn") == "vuelta":
            vuelta()
        else:
            una_tarea(t["nombre"], t["prompt"], modelo_de(t.get("modelo", "")))
        ESTADO["ultima"][t["id"]] = datetime.datetime.now().strftime("%H:%M")
    finally:
        ESTADO["corriendo"] = None; candado_tareas.release()

def reloj():
    hecho = set()
    while True:
        n = datetime.datetime.now()
        if CONF.get("tareas", True):
            for t in TAREAS:
                k = t["id"] + n.strftime("%Y%m%d%H%M")
                if t["cuando"](n) and k not in hecho:
                    hecho.add(k); threading.Thread(target=correr_tarea, args=(t,), daemon=True).start()
        ESTADO["proxima"] = (n.replace(minute=0, second=0) + datetime.timedelta(hours=1)).strftime("%H:%M")
        time.sleep(20)

# ---------- chat del Gerente: un Claude Code vivo, al que se le escribe mientras trabaja
SES_RUTA = os.path.join(OFI, ".gerente")
GER = {"proc": None, "ocupado": False, "pendientes": 0}
candado_ger = threading.Lock()

def sesion_guardada():
    """La conversación del Gerente parte limpia cada día: así no arrastra todo lo anterior (más rápido y gasta menos)."""
    try:
        if datetime.date.fromtimestamp(os.path.getmtime(SES_RUTA)) != datetime.date.today(): return None
        return open(SES_RUTA).read().strip() or None
    except OSError: return None

def iniciar_gerente():
    if GER["proc"] and GER["proc"].poll() is None: return True
    if not claude_bin():
        avisar("gerente", "error", "No encuentro Claude Code en este computador. Pídele a Claude en la app que lo instale (Parte E del cerebro).")
        return False
    try:
        GER["dia"] = datetime.date.today()
        GER["proc"] = subprocess.Popen(comando_claude(GERENTE, sesion_guardada(), entrada_stream=True, modelo=modelo_de("trabajo")), cwd=TIENDA,
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                       text=True, encoding="utf-8", errors="replace", bufsize=1, **SIN_VENTANA)
    except OSError as e:
        avisar("gerente", "error", "No pude abrir Claude Code: " + str(e)); return False
    def guardar(sid):
        if sid: open(SES_RUTA, "w").write(sid)
    def termino(final):
        GER["pendientes"] = max(0, GER["pendientes"] - 1)
        GER["ocupado"] = GER["pendientes"] > 0
        if not final.get("ok") and final.get("texto"):
            if not revisar_limite(final["texto"]): avisar("gerente", "error", final["texto"][:300])
        avisar("gerente", "fin", "listo")
    def leer():
        leer_eventos(GER["proc"], "gerente", al_terminar=termino, al_iniciar=guardar)
        GER["ocupado"] = False; GER["pendientes"] = 0
    threading.Thread(target=leer, daemon=True).start()
    return True

def escribir_gerente(msg):
    with candado_ger:
        # día nuevo: si el Gerente está libre, parte una conversación nueva
        if GER["proc"] and GER["proc"].poll() is None and not GER["ocupado"] and GER.get("dia") != datetime.date.today():
            try: GER["proc"].terminate()
            except Exception: pass
            GER["proc"] = None
        if not iniciar_gerente(): return False
        linea = json.dumps({"type": "user", "message": {"role": "user", "content": [{"type": "text", "text": msg}]}}, ensure_ascii=False)
        try:
            GER["proc"].stdin.write(linea + "\n"); GER["proc"].stdin.flush()
        except (OSError, ValueError):
            GER["proc"] = None
            if not iniciar_gerente(): return False
            GER["proc"].stdin.write(linea + "\n"); GER["proc"].stdin.flush()
        GER["pendientes"] += 1; GER["ocupado"] = True
        return True

# ---------- bandeja con botones: lo que apruebe el jefe dispara la oficina sola
BAN_RUTA = os.path.join(OFI, "Bandeja.md")
candado_ban = threading.Lock()

def productos_de(texto):
    m = texto.split(":", 1)[1] if ":" in texto else texto
    m = m.split("Para los que")[0]
    return [x.replace("🔥", "").replace("…", "").strip(" .*") for x in m.split(",") if x.replace("🔥", "").strip(" .…*")]

def responder_bandeja(c):
    linea = str(c.get("linea") or "").strip()
    accion = c.get("accion")
    ahora = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    limpio = lambda s: str(s or "").replace("·", "-").replace("\n", " ").strip()[:300]
    with candado_ban:
        try: txt = open(BAN_RUTA, encoding="utf-8").read()
        except OSError: return False, "No encuentro la bandeja"
        filas = txt.split("\n")
        i = next((k for k, l in enumerate(filas) if l.strip() == linea), None)
        if i is None: return False, "Esa línea ya cambió en la bandeja. Actualiza la oficina."
        fila = filas[i]
        if accion == "producto":
            p, dec = limpio(c.get("producto")), ("aprobado" if c.get("decision") == "aprobado" else "rechazado")
            extra = f" · {p}: {dec}" + (f" · Dropi {limpio(c.get('dropi'))} · proveedor {limpio(c.get('precio'))} · stock {limpio(c.get('stock'))}" if dec == "aprobado" else "")
            fila += extra
            todos = productos_de(linea.split(" · ", 3)[-1])
            hechos = [x for x in todos if f" · {x}: aprobado" in fila or f" · {x}: rechazado" in fila]
            if todos and len(hechos) >= len(todos):
                fila = fila.replace("- [ ]", "- [x]", 1)
            if dec == "aprobado":
                orden = (f"[Bandeja] El jefe aprobó el producto {p} (link de Dropi: {limpio(c.get('dropi')) or 'sin dato'}, precio del proveedor: {limpio(c.get('precio')) or 'sin dato'}, stock: {limpio(c.get('stock')) or 'sin dato'}). "
                         "Anótalo en el radar como aprobado con esos datos y lanza al investigador en modo automático; la cadena sigue sola. Cuéntale al jefe en una línea qué partió.")
            else:
                orden = f"[Bandeja] El jefe rechazó el producto {p}. Márcalo rechazado en el radar. Respóndele en una línea."
        else:
            textos = {"publicar": "PUBLICAR", "dejar": "dejarlo en borrador", "apagar": "APAGAR", "mantener": "dejarlo corriendo",
                      "listo": "ya lo hice", "responder": limpio(c.get("texto"))}
            resp = textos.get(accion)
            if not resp: return False, "Acción desconocida"
            fila = fila.replace("- [ ]", "- [x]", 1) + f" · RESPUESTA ({ahora}): {resp}"
            item = linea[5:].strip()
            orden = {
                "publicar": f"[Bandeja] El jefe apretó PUBLICAR en su bandeja para: «{item}». Ese botón es su sí explícito para publicar exactamente ese testeo, con esos anuncios y ese presupuesto. Publícalo con campanas-drop-nation (Paso 6), revisa que quedó activo, anótalo en Campañas.md y cuéntale en una línea.",
                "dejar": f"[Bandeja] El jefe decidió dejar en borrador: «{item}». No publiques nada. Anótalo y respóndele en una línea.",
                "apagar": f"[Bandeja] El jefe aprobó en su bandeja: «{item}». Ese botón es su sí: apaga (pausa) solo el anuncio o la campaña que dice esa alerta, con el conector de Meta Ads; no toques nada más. Anótalo en Campañas.md y en Métricas.md y cuéntale en una línea.",
                "mantener": f"[Bandeja] El jefe decidió no apagar: «{item}». No cambies nada en Meta. Anótalo en Métricas.md y respóndele en una línea.",
                "listo": f"[Bandeja] El jefe dice que ya resolvió: «{item}». Revisa que esté resuelto y sigue la cadena (cerebro-drop-nation, Parte D). Cuéntale en una línea.",
                "responder": f"[Bandeja] El jefe respondió a «{item}»: {resp}. Úsalo y sigue con lo pendiente (cerebro-drop-nation, Parte D). Cuéntale en una línea.",
            }[accion]
        filas[i] = fila
        open(BAN_RUTA, "w", encoding="utf-8").write("\n".join(filas))
    avisar("gerente", "paso", "Bandeja: " + ({"producto": "decisión de producto"}.get(accion) or accion), "oficina")
    return escribir_gerente(orden), ""

# ---------- visor: archivos de la tienda para ver dentro de la app (solo lectura, solo dentro de la carpeta de la tienda)
import mimetypes, glob as _glob
VISOR = {
    "anuncios": ["Productos/*/Anuncios/Videos ads/*.mp4"],
    "productos": ["Productos/*/Contexto del producto.md", "Productos/*/Imágenes/*.*"],
    "guiones": ["Productos/*/Anuncios/Guiones.md", "Productos/*/Anuncios/Textos Meta.md"],
    "radar": ["Radar/Radar de productos.md"],
    "metricas": ["Bases/Reportes de la tienda.md", "Productos/*/Métricas.md", "Productos/*/Campañas.md", "Bases/Tablero de productos.md"],
    "visuales": ["Oficina/Visuales/*.*"],
}
def ruta_segura(rel):
    rel = str(rel or "").replace("\\", "/").lstrip("/")
    full = os.path.realpath(os.path.join(TIENDA, rel))
    if not (full == os.path.realpath(TIENDA) or full.startswith(os.path.realpath(TIENDA) + os.sep)): return None
    return full if os.path.isfile(full) else None

def listar(seccion):
    out = []
    for patron in VISOR.get(seccion, []):
        for f in _glob.glob(os.path.join(TIENDA, patron)):
            if os.path.isfile(f) and not os.path.basename(f).startswith("."):
                rel = os.path.relpath(f, TIENDA).replace(os.sep, "/")
                partes = rel.split("/")
                out.append({"ruta": rel, "nombre": os.path.basename(f), "producto": partes[1] if partes[0] == "Productos" and len(partes) > 1 else "",
                            "tipo": (mimetypes.guess_type(f)[0] or ("text/markdown" if f.endswith(".md") else "")).split("/")[0] if not f.endswith(".md") else "md",
                            "fecha": datetime.datetime.fromtimestamp(os.path.getmtime(f)).strftime("%Y-%m-%d %H:%M")})
    out.sort(key=lambda x: x["fecha"], reverse=True)
    return out

# ---------- actualizaciones: la app avisa cuando hay una version nueva y se actualiza con un boton
REPO = "https://github.com/dropnationlatam/OFICINA-DROP-NATION"
VERSION_URL = "https://raw.githubusercontent.com/dropnationlatam/OFICINA-DROP-NATION/main/VERSION"
BASE_INST = os.path.join(os.path.expanduser("~"), ".claude", "oficina-drop-nation")
ACT = {"nueva": "", "estado": ""}
def version_local():
    try: return open(os.path.join(BASE_INST, "VERSION")).read().strip()
    except OSError: return ""
def revisar_version():
    while True:
        try:
            with urllib.request.urlopen(urllib.request.Request(VERSION_URL, headers={"User-Agent": "OficinaDropNation"}), timeout=20) as r:
                remota = r.read().decode().strip()
            ACT["nueva"] = remota if remota and remota != version_local() else ""
        except Exception: pass
        time.sleep(6 * 3600)

def actualizar():
    """Baja la ultima version, la instala (skills, app y herramientas) y reinicia la oficina."""
    import tempfile
    ACT["estado"] = "bajando"; avisar("gerente", "paso", "Actualizando la oficina", "oficina")
    tmp = os.path.join(tempfile.gettempdir(), "_dn_act")
    shutil.rmtree(tmp, ignore_errors=True)
    r = subprocess.run(["git", "clone", "--depth", "1", REPO, tmp], capture_output=True, text=True, **SIN_VENTANA)
    if r.returncode != 0 or not os.path.isdir(os.path.join(tmp, "skills")):
        ACT["estado"] = "error"; avisar("gerente", "error", "No pude bajar la actualización (revisa internet y que git esté instalado)."); return
    ACT["estado"] = "instalando"
    if os.name == "nt":
        cmd = ["powershell", "-ExecutionPolicy", "Bypass", "-File", os.path.join(tmp, "instalar.ps1"), tmp]
    else:
        cmd = ["bash", os.path.join(tmp, "instalar.sh"), tmp]
    r = subprocess.run(cmd, capture_output=True, text=True, **SIN_VENTANA)
    registro("Actualización: " + (r.stdout or r.stderr or "")[-400:].replace("\n", " | "))
    # en Mac, reemplazar la app que quedo en Aplicaciones por la nueva
    nueva_app = os.path.join(BASE_INST, "plantillas", "Oficina.app")
    if sys.platform == "darwin" and os.path.isdir(nueva_app):
        for destino in ("/Applications/Oficina.app", os.path.expanduser("~/Applications/Oficina.app")):
            if os.path.isdir(destino):
                try:
                    shutil.rmtree(destino); shutil.copytree(nueva_app, destino, symlinks=True)
                    os.chmod(os.path.join(destino, "Contents", "MacOS", "Oficina"), 0o755)
                    subprocess.run(["xattr", "-cr", destino], capture_output=True)
                except OSError as e: registro("No pude reemplazar la app: " + str(e))
    shutil.rmtree(tmp, ignore_errors=True)
    ACT["estado"] = "reiniciando"; ACT["nueva"] = ""
    registro("Oficina actualizada a la versión " + version_local() + "; reiniciando")
    try:
        if GER["proc"] and GER["proc"].poll() is None: GER["proc"].terminate()
    except Exception: pass
    time.sleep(1)
    script = os.path.join(BASE_INST, "herramientas", "oficina.py")
    if not os.path.exists(script): script = os.path.abspath(__file__)
    args = [sys.executable, "-I", script, TIENDA, "--sin-navegador", "--reinicio"]
    if os.name == "nt":
        subprocess.Popen(args, **SIN_VENTANA); os._exit(0)
    else:
        os.execv(sys.executable, args)

# ---------- servidor
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def seguro(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("localhost", "127.0.0.1")
    def enviar(self, cod, cuerpo, tipo="application/json; charset=utf-8"):
        b = cuerpo.encode("utf-8") if isinstance(cuerpo, str) else cuerpo
        self.send_response(cod); self.send_header("Content-Type", tipo); self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def enviar_archivo(self, f):
        tipo = "text/markdown; charset=utf-8" if f.endswith(".md") else (mimetypes.guess_type(f)[0] or "application/octet-stream")
        tam = os.path.getsize(f); rango = self.headers.get("Range")
        ini, fin = 0, tam - 1
        if rango and rango.startswith("bytes="):
            a, _, b = rango[6:].split(",")[0].partition("-")
            try:
                if a: ini = int(a); fin = int(b) if b else tam - 1
                else: ini = tam - int(b)
            except ValueError: pass
            fin = min(fin, tam - 1)
            self.send_response(206); self.send_header("Content-Range", f"bytes {ini}-{fin}/{tam}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", tipo); self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(fin - ini + 1)); self.send_header("Cache-Control", "no-store"); self.end_headers()
        with open(f, "rb") as fh:
            fh.seek(ini); falta = fin - ini + 1
            while falta > 0:
                trozo = fh.read(min(65536, falta))
                if not trozo: break
                try: self.wfile.write(trozo)
                except (BrokenPipeError, ConnectionResetError): return
                falta -= len(trozo)
    def api_ok(self):
        return self.seguro() and self.headers.get("X-Oficina-Clave") == CLAVE
    def do_GET(self):
        if not self.seguro(): return self.enviar(403, "{}")
        ruta = self.path.split("?")[0]
        if ruta in ("/", "/index.html"):
            html = open(os.path.join(AQUI, "Oficina.html"), encoding="utf-8").read()
            return self.enviar(200, html, "text/html; charset=utf-8")
        if ruta == "/datos.js":
            d = panel.construir(TIENDA)
            if VIVO: d["vivo"] = dict(VIVO)
            return self.enviar(200, "window.OFICINA = " + json.dumps(d, ensure_ascii=False) + ";", "application/javascript; charset=utf-8")
        if ruta == "/api/feed" and self.api_ok():
            try: desde = int((self.path.split("desde=") + ["0"])[1].split("&")[0])
            except ValueError: desde = 0
            with candado_feed: nuevos = [x for x in FEED if x["n"] > desde]
            return self.enviar(200, json.dumps({"items": nuevos, "ocupado": GER["ocupado"], "tarea": ESTADO["corriendo"]}, ensure_ascii=False))
        if ruta == "/api/visor" and self.api_ok():
            sec = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("s", [""])[0]
            return self.enviar(200, json.dumps({"archivos": listar(sec)}, ensure_ascii=False))
        if ruta == "/archivo":
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if q.get("k", [""])[0] != CLAVE: return self.enviar(403, "{}")
            f = ruta_segura(q.get("r", [""])[0])
            if not f: return self.enviar(404, "{}")
            return self.enviar_archivo(f)
        if ruta == "/api/registro" and self.api_ok():
            return self.enviar(200, json.dumps({"registro": leer_registro()}, ensure_ascii=False))
        if ruta == "/api/revision" and self.api_ok():
            return self.enviar(200, json.dumps(REV, ensure_ascii=False))
        if ruta == "/api/estado" and self.api_ok():
            return self.enviar(200, json.dumps({"claude": bool(claude_bin()), "gerente": GER["ocupado"], "version": version_local(),
                                                "actualizacion": ACT["nueva"], "actualizando": ACT["estado"], "tienda_ruta": TIENDA, "limite": en_pausa_por_limite(), **ESTADO}, ensure_ascii=False))
        self.enviar(404, "{}")
    def do_POST(self):
        if not self.api_ok(): return self.enviar(403, "{}")
        largo = int(self.headers.get("Content-Length") or 0)
        try: cuerpo = json.loads(self.rfile.read(largo) or b"{}")
        except ValueError: return self.enviar(400, "{}")
        if self.path == "/api/chat":
            msg = str(cuerpo.get("msg", "")).strip()[:4000]
            if not msg: return self.enviar(400, "{}")
            if GER["ocupado"]:
                with candado_feed:
                    ult = next((x["texto"] for x in reversed(FEED) if x["quien"] == "gerente" and x["tipo"] == "paso"), "")
                avisar("gerente", "texto", "Te leí, jefe. " + (f"Ahora estoy en: {ult}. " if ult else "") + "Te respondo apenas termine este paso.")
            ok = escribir_gerente(msg)
            return self.enviar(200, json.dumps({"ok": ok}))
        if self.path == "/api/actualizar":
            if ACT["estado"] in ("bajando", "instalando", "reiniciando"): return self.enviar(200, json.dumps({"ok": True}))
            threading.Thread(target=actualizar, daemon=True).start()
            return self.enviar(200, json.dumps({"ok": True}))
        if self.path == "/api/revisar":
            if REV["estado"] != "revisando": threading.Thread(target=probar, args=(True,), daemon=True).start()
            return self.enviar(200, json.dumps({"ok": True}))
        if self.path == "/api/abrir-carpeta":
            return self.enviar(200, json.dumps({"ok": abrir_carpeta()}))
        if self.path == "/api/reiniciar-gerente":
            threading.Thread(target=reiniciar_gerente, daemon=True).start()
            return self.enviar(200, json.dumps({"ok": True}))
        if self.path == "/api/cerrar":
            self.enviar(200, json.dumps({"ok": True}))
            registro("Oficina cerrada desde la ventana")
            def salir():
                try: os.remove(os.path.join(OFI, ".url"))
                except OSError: pass
                os._exit(0)
            threading.Timer(0.5, salir).start()
            return
        if self.path == "/api/bandeja":
            ok, err = responder_bandeja(cuerpo)
            return self.enviar(200, json.dumps({"ok": ok, "error": err}, ensure_ascii=False))
        if self.path == "/api/tarea":
            t = next((x for x in TAREAS if x["id"] == cuerpo.get("id")), None)
            if not t: return self.enviar(400, "{}")
            threading.Thread(target=correr_tarea, args=(t,), daemon=True).start()
            return self.enviar(200, json.dumps({"ok": True}))
        self.enviar(404, "{}")

REV = {"estado": "", "lineas": [], "ok": None, "hora": ""}
def probar(desde_app=False):
    """Revisa que la oficina pueda trabajar sola y dice qué falta. Uso: oficina.py "<tienda>" --probar (o el botón Revisar de la app)"""
    ok = True
    if desde_app:
        REV.update(estado="revisando", lineas=[], ok=None, hora=datetime.datetime.now().strftime("%H:%M"))
    def linea(bien, txt):
        if desde_app: REV["lineas"].append({"ok": bool(bien), "texto": txt})
        else: print(("✅ " if bien else "❌ ") + txt, flush=True)
    cb = claude_bin()
    linea(bool(cb), "Claude Code instalado" + (f" ({cb})" if cb else ": instálalo y vuelve a probar"))
    ok &= bool(cb)
    if cb:
        try:
            r = subprocess.run([cb, "auth", "status"], capture_output=True, text=True, timeout=60, **SIN_VENTANA)
            linea(r.returncode == 0, "Sesión iniciada en Claude Code" if r.returncode == 0 else "Claude Code sin sesión: corre `claude` en una terminal e inicia sesión")
            ok &= r.returncode == 0
        except Exception as e:
            linea(False, "No pude revisar la sesión de Claude Code: " + str(e)[:80]); ok = False
        r = correr_claude("Responde solo la palabra OK.", quien="prueba", timeout=300)
        bien = r["ok"] and "OK" in r["texto"].upper()
        linea(bien, f"Claude Code corre solo con permisos '{CONF['permisos']}'" if bien else f"Claude Code no corrió con permisos '{CONF['permisos']}': {r['texto'][:160]}")
        ok &= bien
    if dominio():
        try:
            leer_ventas(); linea("pedidos" in VIVO, f"Shopify: ventas de hoy ({VIVO.get('pedidos', '?')} pedidos)")
        except Exception as e:
            linea(False, "Shopify ventas: " + str(getattr(e, "code", "") or e)[:120] + " (revisa el dominio, el Client ID y el Client secret, y que la app esté instalada con read_orders)"); ok = False
        try:
            leer_trafico(); linea("visitas" in VIVO, f"Shopify: visitas y carritos de hoy ({VIVO.get('visitas', '?')} visitas)" if "visitas" in VIVO else "Shopify: visitas y carritos (revisa el permiso read_reports)")
        except Exception as e:
            linea(False, "Shopify visitas: " + str(e)[:120] + " (revisa el permiso read_reports)")
    else:
        linea(False, "Shopify al minuto sin configurar (opcional): pega shopify_tienda, shopify_client_id y shopify_client_secret en Oficina/oficina.json")
    git = shutil.which("git")
    linea(bool(git), "Git instalado (para el botón Actualizar)" if git else "Falta Git: sin él no funciona el botón Actualizar. Pídele a Claude que lo instale")
    ok &= bool(git)
    for f in ("Bitácora.md", "Bandeja.md", "Estado.md"):
        linea(os.path.exists(os.path.join(OFI, f)), "Oficina/" + f)
    if desde_app:
        REV.update(estado="listo", ok=bool(ok)); registro("Revisión desde la app: " + ("todo listo" if ok else "faltan cosas"))
    else:
        print("\nTODO LISTO" if ok else "\nFALTAN COSAS (arriba con ❌)", flush=True)
    return ok

def abrir_carpeta():
    try:
        if os.name == "nt": os.startfile(TIENDA)
        elif sys.platform == "darwin": subprocess.Popen(["open", TIENDA])
        else: subprocess.Popen(["xdg-open", TIENDA])
        return True
    except Exception as e:
        registro("No pude abrir la carpeta: " + str(e)); return False

def leer_registro(n=200):
    salida = []
    for nombre in ("Tareas.log", "oficina.log"):
        try:
            with open(os.path.join(OFI, nombre), encoding="utf-8", errors="replace") as f:
                lineas = [re.sub(r"#k=[\w-]+", "#k=…", l) for l in f.read().splitlines()[-n:]]
            salida.append({"archivo": nombre, "lineas": lineas})
        except OSError:
            salida.append({"archivo": nombre, "lineas": []})
    return salida

def reiniciar_gerente():
    """Corta el Gerente y borra su sesión: la próxima vez parte con una conversación nueva."""
    with candado_ger:
        try:
            if GER["proc"] and GER["proc"].poll() is None: GER["proc"].terminate()
        except Exception: pass
        GER.update(proc=None, ocupado=False, pendientes=0)
        try: os.remove(SES_RUTA)
        except OSError: pass
    registro("Gerente reiniciado desde la app")
    avisar("gerente", "texto", "Listo, jefe. Partí con una conversación nueva. ¿En qué te ayudo?")

def recordar_tienda():
    """Guarda la carpeta de la tienda para que la app Oficina sepa cual abrir."""
    ruta = os.path.join(os.path.expanduser("~"), ".claude", "oficina-drop-nation", "tienda.txt")
    try:
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        with open(ruta, "w", encoding="utf-16" if os.name == "nt" else "utf-8") as f: f.write(TIENDA + "\n")
    except OSError: pass

def sin_suspender():
    """En Windows, que el computador no se duerma mientras la oficina este abierta (en Mac lo hace caffeinate)."""
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)
        except Exception: pass

if __name__ == "__main__":
    recordar_tienda()
    if "--probar" in sys.argv:
        sys.exit(0 if probar() else 1)
    srv = None
    for intento in range(20 if "--reinicio" in sys.argv else 1):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", PUERTO), H); break
        except OSError:
            time.sleep(0.5)
    if not srv:
        print("La oficina ya está abierta en este computador.", flush=True); sys.exit(0)
    sin_suspender()
    threading.Thread(target=reloj, daemon=True).start()
    threading.Thread(target=ventas_al_minuto, daemon=True).start()
    threading.Thread(target=revisar_version, daemon=True).start()
    url = f"http://localhost:{PUERTO}/#k={CLAVE}"
    URLF = os.path.join(OFI, ".url")
    with open(URLF, "w", encoding="ascii") as f: f.write(url + "\n")
    import atexit
    atexit.register(lambda: os.path.exists(URLF) and os.remove(URLF))
    print("Oficina abierta en", f"http://localhost:{PUERTO}", flush=True)
    print("Deja esta ventana abierta: mientras esté abierta, la oficina trabaja sola.", flush=True)
    if "--sin-navegador" not in sys.argv:
        try: webbrowser.open(url)
        except Exception: pass
    try: srv.serve_forever()
    except KeyboardInterrupt: print("Oficina cerrada.")
    finally:
        try: os.remove(URLF)
        except OSError: pass
