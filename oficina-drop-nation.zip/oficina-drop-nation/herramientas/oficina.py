# Oficina Drop Nation: la app local de la oficina.
# - Sirve la oficina visual en http://localhost:8765 con los datos de la carpeta de la tienda.
# - El chat del Gerente es Claude Code de verdad (claude -p) trabajando en la carpeta de la tienda.
# - Corre las tareas de la oficina a su hora: cada hora (despachador), 9:00 (reporte) y 12:00 (buscador).
# Uso: python3 -I oficina.py "<carpeta de la tienda>"   (en Windows: python -I oficina.py ...)
import sys, os, json, time, uuid, shutil, secrets, threading, subprocess, datetime, webbrowser, importlib.util, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

AQUI = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("panel", os.path.join(AQUI, "panel.py"))
panel = importlib.util.module_from_spec(spec); spec.loader.exec_module(panel)

if len(sys.argv) < 2:
    print('Uso: python3 -I oficina.py "<carpeta de la tienda>"'); sys.exit(1)
TIENDA = os.path.abspath(sys.argv[1])
OFI = os.path.join(TIENDA, "Oficina")
os.makedirs(OFI, exist_ok=True)
PUERTO = 8765
CLAVE = secrets.token_urlsafe(16)
CONF_RUTA = os.path.join(OFI, "oficina.json")
CONF = {"permisos": "auto", "tareas": True, "presupuesto_usd_por_tarea": 5,
        "shopify_tienda": "", "shopify_client_id": "", "shopify_client_secret": "", "shopify_token": "", "shopify_api": "2026-10",
        "horario_tareas": "7-23"}
try:
    CONF.update(json.load(open(CONF_RUTA, encoding="utf-8")))
except (OSError, ValueError):
    pass
json.dump(CONF, open(CONF_RUTA, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

GERENTE = ("Eres el Gerente de la Oficina Drop Nation de esta tienda y hablas por el chat de la oficina. "
           "Al dueño le dices 'jefe'. Español de Chile, mensajes cortos, sin jerga. Trabajas en la carpeta de la tienda (el directorio actual). "
           "Para saber qué pasa lee Oficina/Estado.md, Oficina/Bitácora.md, Oficina/Bandeja.md, Bases/Tablero de productos.md y Bases/Reportes de la tienda.md. "
           "Cuando el jefe te pida algo, hazlo con las skills de Drop Nation (cerebro-drop-nation y la del agente que corresponda) y anota en la bitácora como dicen las skills. "
           "Si aprueba productos o responde algo de la bandeja, anótalo donde corresponde (radar, bandeja). "
           "Nunca publiques campañas, subas presupuestos, publiques en Shopify ni gastes plata sin un sí explícito del jefe en este chat que nombre qué se publica. "
           "No hagas preguntas de opciones: pregunta en texto, en una sola línea.")

def en_horario(n):
    """La vuelta de cada hora corre solo en este horario (oficina.json, horario_tareas, por defecto 7 a 23) para no gastar de noche."""
    try:
        ini, fin = [int(x) for x in str(CONF.get("horario_tareas", "7-23")).split("-")]
    except ValueError:
        return True
    return ini <= n.hour <= fin

TAREAS = [
    {"id": "hora", "nombre": "Oficina · cada hora", "cuando": lambda n: n.minute == 0 and en_horario(n),
     "prompt": "Modo automático: usa la skill cerebro-drop-nation, Parte D. Revisa la oficina y lanza lo pendiente. No publiques nada."},
    {"id": "reporte", "nombre": "Reporte del día", "cuando": lambda n: n.hour == 9 and n.minute == 5,
     "prompt": "Modo automático: usa la skill campanas-drop-nation y haz el reporte de la tienda (Parte 3; si hay un solo testeo, la Parte 2)."},
    {"id": "buscador", "nombre": "Buscador del día", "cuando": lambda n: n.hour == 12 and n.minute == 5,
     "prompt": "Modo automático: usa la skill buscador-drop-nation y busca 10 productos. Deja los nuevos en la bandeja."},
]

def claude_bin():
    for n in ("claude", "claude.cmd", "claude.exe"):
        p = shutil.which(n)
        if p: return p
    for p in (os.path.expanduser("~/.local/bin/claude"), os.path.expanduser("~/.claude/local/claude")):
        if os.path.exists(p): return p
    return None

def registro(txt):
    with open(os.path.join(OFI, "Tareas.log"), "a", encoding="utf-8") as f:
        f.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M") + " · " + txt + "\n")

def correr_claude(prompt, sesion=None, extra=None, timeout=7200):
    cb = claude_bin()
    if not cb:
        return {"ok": False, "texto": "No encuentro Claude Code en este computador. Pídele a Claude en la app que lo instale (Parte E del cerebro)."}
    cmd = [cb, "-p", prompt, "--output-format", "json", "--permission-mode", CONF["permisos"],
           "--max-budget-usd", str(CONF.get("presupuesto_usd_por_tarea", 5))]
    if sesion: cmd += ["--resume", sesion]
    if extra: cmd += ["--append-system-prompt", extra]
    try:
        r = subprocess.run(cmd, cwd=TIENDA, capture_output=True, text=True, timeout=timeout, encoding="utf-8")
    except subprocess.TimeoutExpired:
        return {"ok": False, "texto": "La tarea pasó el tiempo máximo y se cortó."}
    try:
        j = json.loads(r.stdout.strip().splitlines()[-1])
        return {"ok": not j.get("is_error"), "texto": j.get("result") or "(sin respuesta)", "sesion": j.get("session_id")}
    except (ValueError, IndexError):
        return {"ok": False, "texto": (r.stderr or r.stdout or "Claude Code no respondió.").strip()[-600:]}

# ---------- ventas, visitas y carritos de Shopify al minuto
# Necesita una app de la tienda creada en el Dev Dashboard de Shopify (permisos read_orders y read_reports),
# instalada en la tienda. El alumno pega en Oficina/oficina.json su client_id y client_secret (nunca en el chat).
# Con eso la oficina pide sola un token cada 24 horas. Tambien acepta un token fijo de una app antigua (shopify_token).
import urllib.request, urllib.error
VIVO = {}
TOKEN = {"valor": "", "vence": 0}

def dominio():
    d = (CONF.get("shopify_tienda") or "").strip().replace("https://", "").replace("http://", "").strip("/")
    if d and not d.endswith(".myshopify.com"): d += ".myshopify.com"
    return d

def token_shopify():
    if (CONF.get("shopify_token") or "").strip():
        return CONF["shopify_token"].strip()
    cid, sec = (CONF.get("shopify_client_id") or "").strip(), (CONF.get("shopify_client_secret") or "").strip()
    if not (dominio() and cid and sec): return ""
    if TOKEN["valor"] and time.time() < TOKEN["vence"]: return TOKEN["valor"]
    cuerpo = urllib.parse.urlencode({"grant_type": "client_credentials", "client_id": cid, "client_secret": sec}).encode()
    req = urllib.request.Request(f"https://{dominio()}/admin/oauth/access_token", data=cuerpo,
                                 headers={"Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json", "User-Agent": "OficinaDropNation"})
    with urllib.request.urlopen(req, timeout=20) as r:
        j = json.load(r)
    TOKEN["valor"] = j.get("access_token", "")
    TOKEN["vence"] = time.time() + int(j.get("expires_in") or 3600) - 300
    return TOKEN["valor"]

def gql(query, variables):
    tk = token_shopify()
    if not tk: return None
    cuerpo = json.dumps({"query": query, "variables": variables}).encode()
    req = urllib.request.Request(f"https://{dominio()}/admin/api/{CONF.get('shopify_api', '2026-10')}/graphql.json", data=cuerpo,
                                 headers={"X-Shopify-Access-Token": tk, "Content-Type": "application/json", "User-Agent": "OficinaDropNation"})
    with urllib.request.urlopen(req, timeout=20) as r:
        j = json.load(r)
    if j.get("errors"): raise ValueError(str(j["errors"])[:120])
    return j.get("data") or {}

PEDIDOS = """query($q:String!){orders(first:250, query:$q, sortKey:CREATED_AT, reverse:true){nodes{
 name createdAt cancelledAt totalPriceSet{shopMoney{amount}} lineItems(first:1){nodes{title}}}}}"""

def leer_ventas():
    hoy = datetime.datetime.now().astimezone().replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    d = gql(PEDIDOS, {"q": f"created_at:>='{hoy}'"})
    if d is None: return
    pedidos = [o for o in ((d.get("orders") or {}).get("nodes") or []) if not o.get("cancelledAt")]
    def monto(o):
        try: return float(o["totalPriceSet"]["shopMoney"]["amount"])
        except (KeyError, TypeError, ValueError): return 0.0
    def hora(o):
        try: return datetime.datetime.fromisoformat(o["createdAt"].replace("Z", "+00:00")).astimezone().strftime("%H:%M")
        except (KeyError, ValueError): return ""
    VIVO.pop("error", None)
    VIVO.update({
        "actualizado": datetime.datetime.now().strftime("%H:%M"),
        "pedidos": len(pedidos),
        "facturacion": round(sum(monto(o) for o in pedidos)),
        "ultimas": [{"hora": hora(o),
                     "producto": (((o.get("lineItems") or {}).get("nodes") or [{}])[0].get("title") or o.get("name") or ""),
                     "monto": round(monto(o))} for o in pedidos[:5]],
    })

SESIONES = "query($q:String!){shopifyqlQuery(query:$q){parseErrors tableData{columns{name} rows}}}"

def leer_trafico():
    """Visitas, sesiones con agregado al carrito y % de agregados al carrito de hoy (ShopifyQL)."""
    res = None
    for rango in ("DURING today", "SINCE today"):
        d = gql(SESIONES, {"q": "FROM sessions SHOW sessions, sessions_with_cart_additions, added_to_cart_rate " + rango})
        if d is None: return
        res = d.get("shopifyqlQuery") or {}
        if not res.get("parseErrors"): break
    tabla = (res or {}).get("tableData") or {}
    filas = tabla.get("rows") or []
    if not filas: return
    fila = filas[0]
    if isinstance(fila, list):
        fila = {c.get("name"): v for c, v in zip(tabla.get("columns") or [], fila)}
    def n(v):
        try: return float(v)
        except (TypeError, ValueError): return None
    vis, car, pct = n(fila.get("sessions")), n(fila.get("sessions_with_cart_additions")), n(fila.get("added_to_cart_rate"))
    if pct is None and vis: pct = (car or 0) / vis
    if vis is not None: VIVO["visitas"] = int(vis)
    if car is not None: VIVO["carritos"] = int(car)
    if pct is not None: VIVO["pct_carrito"] = round(pct * 100, 1)

def ventas_al_minuto():
    while True:
        try: leer_ventas()
        except Exception as e: VIVO.update({"error": "Shopify no respondió: " + str(getattr(e, "code", "") or e)[:80]})
        try: leer_trafico()
        except Exception: pass
        time.sleep(60)

# ---------- tareas programadas
ESTADO = {"corriendo": None, "ultima": {}, "proxima": ""}
candado_tareas = threading.Lock()

def correr_tarea(t):
    if not candado_tareas.acquire(blocking=False):
        registro(t["nombre"] + " · saltada: otra tarea sigue corriendo"); return
    try:
        ESTADO["corriendo"] = t["nombre"]; registro(t["nombre"] + " · parte")
        r = correr_claude(t["prompt"])
        registro(t["nombre"] + (" · terminó" if r["ok"] else " · falló: " + r["texto"][:200]))
        ESTADO["ultima"][t["id"]] = datetime.datetime.now().strftime("%H:%M")
    finally:
        ESTADO["corriendo"] = None; candado_tareas.release()

def reloj():
    hecho = set()
    while True:
        n = datetime.datetime.now()
        if CONF.get("tareas", True):
            for t in TAREAS:
                k = t["id"] + n.strftime("%Y%m%d%H%M")
                if t["cuando"](n) and k not in hecho:
                    hecho.add(k); threading.Thread(target=correr_tarea, args=(t,), daemon=True).start()
        ESTADO["proxima"] = (n.replace(minute=0, second=0) + datetime.timedelta(hours=1)).strftime("%H:%M")
        time.sleep(20)

# ---------- chat del Gerente
CHATS = {}
candado_chat = threading.Lock()
SES_RUTA = os.path.join(OFI, ".gerente")

def responder(cid, msg):
    with candado_chat:
        try: ses = open(SES_RUTA).read().strip() or None
        except OSError: ses = None
        r = correr_claude(msg, sesion=ses, extra=GERENTE, timeout=3600)
        if r.get("sesion"):
            open(SES_RUTA, "w").write(r["sesion"])
        CHATS[cid] = {"listo": True, "texto": r["texto"]}

# ---------- servidor
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def seguro(self):
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("localhost", "127.0.0.1")
    def enviar(self, cod, cuerpo, tipo="application/json; charset=utf-8"):
        b = cuerpo.encode("utf-8") if isinstance(cuerpo, str) else cuerpo
        self.send_response(cod); self.send_header("Content-Type", tipo); self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def api_ok(self):
        return self.seguro() and self.headers.get("X-Oficina-Clave") == CLAVE
    def do_GET(self):
        if not self.seguro(): return self.enviar(403, "{}")
        ruta = self.path.split("?")[0]
        if ruta in ("/", "/index.html"):
            html = open(os.path.join(AQUI, "Oficina.html"), encoding="utf-8").read()
            return self.enviar(200, html, "text/html; charset=utf-8")
        if ruta == "/datos.js":
            d = panel.construir(TIENDA)
            if VIVO: d["vivo"] = dict(VIVO)
            return self.enviar(200, "window.OFICINA = " + json.dumps(d, ensure_ascii=False) + ";", "application/javascript; charset=utf-8")
        if ruta.startswith("/api/chat/") and self.api_ok():
            return self.enviar(200, json.dumps(CHATS.get(ruta.rsplit("/", 1)[1], {"listo": False}), ensure_ascii=False))
        if ruta == "/api/estado" and self.api_ok():
            return self.enviar(200, json.dumps({"claude": bool(claude_bin()), **ESTADO}, ensure_ascii=False))
        self.enviar(404, "{}")
    def do_POST(self):
        if not self.api_ok(): return self.enviar(403, "{}")
        largo = int(self.headers.get("Content-Length") or 0)
        try: cuerpo = json.loads(self.rfile.read(largo) or b"{}")
        except ValueError: return self.enviar(400, "{}")
        if self.path == "/api/chat":
            msg = str(cuerpo.get("msg", "")).strip()[:4000]
            if not msg: return self.enviar(400, "{}")
            cid = uuid.uuid4().hex; CHATS[cid] = {"listo": False}
            threading.Thread(target=responder, args=(cid, msg), daemon=True).start()
            return self.enviar(200, json.dumps({"id": cid}))
        if self.path == "/api/cerrar":
            self.enviar(200, json.dumps({"ok": True}))
            registro("Oficina cerrada desde la ventana")
            def salir():
                try: os.remove(os.path.join(OFI, ".url"))
                except OSError: pass
                os._exit(0)
            threading.Timer(0.5, salir).start()
            return
        if self.path == "/api/tarea":
            t = next((x for x in TAREAS if x["id"] == cuerpo.get("id")), None)
            if not t: return self.enviar(400, "{}")
            threading.Thread(target=correr_tarea, args=(t,), daemon=True).start()
            return self.enviar(200, json.dumps({"ok": True}))
        self.enviar(404, "{}")

def probar():
    """Revisa que la oficina pueda trabajar sola y dice qué falta. Uso: oficina.py "<tienda>" --probar"""
    ok = True
    def linea(bien, txt):
        print(("✅ " if bien else "❌ ") + txt, flush=True)
    cb = claude_bin()
    linea(bool(cb), "Claude Code instalado" + (f" ({cb})" if cb else ": instálalo y vuelve a probar"))
    ok &= bool(cb)
    if cb:
        try:
            r = subprocess.run([cb, "auth", "status"], capture_output=True, text=True, timeout=60)
            linea(r.returncode == 0, "Sesión iniciada en Claude Code" if r.returncode == 0 else "Claude Code sin sesión: corre `claude` en una terminal e inicia sesión")
            ok &= r.returncode == 0
        except Exception as e:
            linea(False, "No pude revisar la sesión de Claude Code: " + str(e)[:80]); ok = False
        r = correr_claude("Responde solo la palabra OK.", timeout=300)
        bien = r["ok"] and "OK" in r["texto"].upper()
        linea(bien, f"Claude Code corre solo con permisos '{CONF['permisos']}'" if bien else f"Claude Code no corrió con permisos '{CONF['permisos']}': {r['texto'][:160]}")
        ok &= bien
    if dominio():
        try:
            leer_ventas(); linea("pedidos" in VIVO, f"Shopify: ventas de hoy ({VIVO.get('pedidos', '?')} pedidos)")
        except Exception as e:
            linea(False, "Shopify ventas: " + str(getattr(e, "code", "") or e)[:120] + " (revisa el dominio, el Client ID y el Client secret, y que la app esté instalada con read_orders)"); ok = False
        try:
            leer_trafico(); linea("visitas" in VIVO, f"Shopify: visitas y carritos de hoy ({VIVO.get('visitas', '?')} visitas)" if "visitas" in VIVO else "Shopify: visitas y carritos (revisa el permiso read_reports)")
        except Exception as e:
            linea(False, "Shopify visitas: " + str(e)[:120] + " (revisa el permiso read_reports)")
    else:
        linea(False, "Shopify al minuto sin configurar (opcional): pega shopify_tienda, shopify_client_id y shopify_client_secret en Oficina/oficina.json")
    for f in ("Bitácora.md", "Bandeja.md", "Estado.md"):
        linea(os.path.exists(os.path.join(OFI, f)), "Oficina/" + f)
    print("\nTODO LISTO" if ok else "\nFALTAN COSAS (arriba con ❌)", flush=True)
    return ok

def recordar_tienda():
    """Guarda la carpeta de la tienda para que la app Oficina sepa cual abrir."""
    ruta = os.path.join(os.path.expanduser("~"), ".claude", "oficina-drop-nation", "tienda.txt")
    try:
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        with open(ruta, "w", encoding="utf-16" if os.name == "nt" else "utf-8") as f: f.write(TIENDA + "\n")
    except OSError: pass

def sin_suspender():
    """En Windows, que el computador no se duerma mientras la oficina este abierta (en Mac lo hace caffeinate)."""
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)
        except Exception: pass

if __name__ == "__main__":
    recordar_tienda()
    if "--probar" in sys.argv:
        sys.exit(0 if probar() else 1)
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PUERTO), H)
    except OSError:
        print("La oficina ya está abierta en este computador.", flush=True); sys.exit(0)
    sin_suspender()
    threading.Thread(target=reloj, daemon=True).start()
    threading.Thread(target=ventas_al_minuto, daemon=True).start()
    url = f"http://localhost:{PUERTO}/#k={CLAVE}"
    URLF = os.path.join(OFI, ".url")
    with open(URLF, "w", encoding="ascii") as f: f.write(url + "\n")
    import atexit
    atexit.register(lambda: os.path.exists(URLF) and os.remove(URLF))
    print("Oficina abierta en", url, flush=True)
    print("Deja esta ventana abierta: mientras esté abierta, la oficina trabaja sola.", flush=True)
    if "--sin-navegador" not in sys.argv:
        try: webbrowser.open(url)
        except Exception: pass
    try: srv.serve_forever()
    except KeyboardInterrupt: print("Oficina cerrada.")
    finally:
        try: os.remove(URLF)
        except OSError: pass
